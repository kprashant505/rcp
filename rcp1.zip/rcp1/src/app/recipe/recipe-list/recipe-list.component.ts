import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Recipe } from '../recipe.model';
//import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {

  recipes: Recipe[] = [
    new Recipe('Recipe One', 'This is just a Test Description', 'https://s3.amazonaws.com/finecooking.s3.tauntonclud.com/app/uploads/2017/04/18170553/051121045-01-broiled-rib-eye-onions-recipe-main.jpg'),
    new Recipe('Recipe Two', 'This is 2nd', 'https://www.finecooking.com/app/themes/finecooking/dist/img/email-interstitial/taco/bg-large.png'),
    new Recipe('Poddar', 'not a recipe', './img/20190328_165350.jpg')
  ];

  constructor() { }

  ngOnInit(): void {
  }

  @Output() theRecipe = new EventEmitter<Recipe>();

  onRecipeSelect(recipe: Recipe) {
    this.theRecipe.emit(recipe);
  }

}
