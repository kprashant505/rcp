// class code will go like venilla javascript.
export class Recipe {
    public name: string;
    public description: string;
    public imgPath: string;

     // Recipe data can be  Instantiatated ouside the recipe class so we need constructor for that.
    constructor( name:string, desc:string, imgPath:string ) {
        this.name = name;
        this.description = desc;
        this.imgPath = imgPath;
    }


}